from flask import Flask, render_template, request, jsonify, send_from_directory
from openai import AzureOpenAI
import config
import json
import requests
import tools
import agents

result = tools.search_for_location({"query":"zincirlikuyu istanbul"})

print(result)
