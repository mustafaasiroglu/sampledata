import os, config, agents, tools, azureopenai, oaistreaming, json, pii
import openai
from openai import AzureOpenAI
from flask import Flask, render_template, redirect, session, url_for, jsonify, request, send_from_directory, stream_with_context
from flask_socketio import SocketIO, emit
from time import sleep
import copy

app = Flask(__name__)
socketio = SocketIO(app,cors_allowed_origins='*')
app.config['JSON_AS_ASCII'] = False
app.secret_key = 'BAD_SECRET_KEY'

mysession ={}

@app.route('/')
def tvcopilot():
    return redirect("/hub")

@app.route('/hub/')
@app.route('/hub/<demo>')
def intro(demo=None):
    if demo == "togg":
        title = "Togg Copilot+"
        bg="togg.jpg"
        agentlist = [
            agents.default_agent,
            agents.carcopilot,
            agents.weathercopilot,
            agents.newscopilot,
            agents.chefcopilot,
            agents.astrologycopilot,
            agents.musiccopilot,
            agents.travelcopilot
            ]
    elif demo == "bank":
        title="Custom Copilots"
        bg="bank.jpg"
        agentlist = [
            agents.default_agent,
            agents.bankfaqcopilot,
            agents.financecopilot,
            agents.newscopilot,
            agents.outboundcallcopilot,
            agents.outboundcallcopilot2,
            agents.bankinternalcopilot
            ]
    else:
        title="Copilot+ Hub"
        bg="background.jpg"
        agentlist = agents.agents

    return render_template('intro.html', agents=agentlist, title=title, bg=bg)

@app.route('/chat/<copilotname>')
def chat(copilotname):
    if copilotname != "custom":
        try:
            mysession['agent'] = getattr(agents, copilotname)
        except:
            mysession['agent'] = agents.default_agent

    pii = request.args.get('pii')
    if pii=="true":
        mysession['pii'] = True
    else:
        mysession['pii'] = False

    mysession['chathistory'] = [{
        "role": "system",
        "content": [
            {
                "type": "text",
                "text": mysession['agent']['system_prompt']
            }
        ],
    },{
        "role": "assistant",
        "content": [
            {
                "type": "text",
                "text": mysession['agent']['initialmessage']
            }
        ]
    }
    ]
    return render_template('chatstreaming.html', agent=mysession['agent'], config=config) 

@app.route('/chat')
def index():
    mysession['agent'] = agents.default_agent
    mode = request.args.get('mode')
    if mode == "promptflow":
        mysession['requestbody'] = {
            "question": "",
            "chat_history": [
            ]
        }
    else:
        mysession['chathistory'] = [{
            "role": "system",
            "content": [
                {
                    "type": "text",
                    "text": agents.default_agent['system_prompt']
                }
            ]
        }]
    return render_template('index.html', mode=mode, config=config) 

@app.route('/generate', methods=['POST'])
def call_openai():
    agent = mysession['agent']
    data = request.get_json()
    message_input = data['text']
    response = azureopenai.get_openai_response(usermessage=message_input,chat_history= mysession['chathistory'],agent=agent)
    return jsonify(response)


openai_client = AzureOpenAI(
    azure_endpoint = config.openai_endpoint, 
    api_key=config.openai_key,  
    api_version="2024-08-01-preview"
)

def stream_processor(response, message_input, replacements):
    
    c = "LLM Input: \t\t" + message_input
    yield(json.dumps({"c":c}))

    pending_tool_calls = []
    function_name = ""
    function_args = ""
    tool_call_id = ""

    original_response = ""
    cumulative_content = ""

    for chunk in response:
        if len(chunk.choices) > 0:
            delta = chunk.choices[0].delta
            if delta.content:
                # yield (json.dumps({"m":delta.content}))
                original_response += delta.content
                cumulative_content += delta.content
                for replacement in replacements:
                    if replacement[1] in cumulative_content:
                        cumulative_content = cumulative_content.replace(replacement[1],replacement[0])
                yield (json.dumps({"mc":cumulative_content}))

            elif delta and delta.tool_calls:
                tcchunklist = delta.tool_calls
                for tcchunk in tcchunklist:
                    if len(pending_tool_calls) <= tcchunk.index:
                        pending_tool_calls.append({"id": "", "type": "function", "function": { "name": "", "arguments": "" } })
                    tc = pending_tool_calls[tcchunk.index]

                    if tcchunk.id:
                        tc["id"] += tcchunk.id
                    if tcchunk.function.name:
                        tc["function"]["name"] += tcchunk.function.name
                    if tcchunk.function.arguments:
                        tc["function"]["arguments"] += tcchunk.function.arguments    

    if original_response!=cumulative_content:   
        c = "\x1B[1mLLM Response: \x1B[m \t" + original_response
        yield(json.dumps({"c":c}))
    if cumulative_content != "":
        c = "\x1B[1mResponse: \x1B[m \t\t" + cumulative_content
        yield(json.dumps({"c":c}))

    if len(pending_tool_calls) > 0:
        mysession['chathistory'].append({
            "role": "assistant",
            "tool_calls": copy.deepcopy(pending_tool_calls)
        })

        while len(pending_tool_calls) > 0:

            for tool_call in pending_tool_calls:

                yield(json.dumps({"f":"<div class='info'> 🌐 " + tool_call["function"]["name"] +" "+ tool_call["function"]["arguments"]}))

                for replacement in replacements:
                    tool_call["function"]["arguments"] = tool_call["function"]["arguments"].replace(replacement[1],replacement[0])

                yield(json.dumps({"c":"\x1B[1mTool Call: \x1B[m \t" + tool_call["function"]["name"] +" "+ tool_call["function"]["arguments"]}))

                try:
                    tool_response = getattr(tools, tool_call["function"]["name"])(json.loads(tool_call["function"]["arguments"]))
                
                except Exception as e:
                    tool_response = "{'Tool function not found or failed. Error': '" + str(e) + "'}"
                
                tool_response_text = json.dumps(tool_response, ensure_ascii=False).encode('utf8').decode()
                yield(json.dumps({"f":"<span class='tooltiptext'>  Result: " + tool_response_text + "</span></div>"}))

                mysession['chathistory'].append({
                    "tool_call_id": tool_call["id"], "role": "tool", "name": tool_call["function"]["name"],
                    "content": [{"type": "text","text":tool_response_text}],
                })

            pending_tool_calls = []
        
            response2 = openai_client.chat.completions.create(
                model = "gpt-4o",
                messages = mysession['chathistory'],
                tools = mysession['agent']['tools'],
                tool_choice = "auto",
                stream=False
                )
            response_text = response2.choices[0].message.content
            if response_text:
                mysession['chathistory'].append({"role": "assistant","content": response_text})
                c = "\x1B[1mLLM Output: \x1B[m \t" + response_text
                yield(json.dumps({"c":c}))
                #make replacements in the response text
                for replacement in replacements:
                    response_text = response_text.replace(replacement[1],replacement[0])
                yield(json.dumps({"mc":response_text}))
            elif response2.choices[0].message.tool_calls:            
                for tc in response2.choices[0].message.tool_calls:
                    pending_tool_calls.append({"id": tc.id, "type": "function", "function": { "name": tc.function.name, "arguments": tc.function.arguments } })
                mysession['chathistory'].append({
                    "role": "assistant",
                    "tool_calls": copy.deepcopy(pending_tool_calls)
                })
            
@app.route('/generatestream', methods=['GET', 'POST'])
def call_openai_stream():
    agent = mysession['agent']
    data = request.get_json()
    if mysession['pii']:
        message_input, replacements = pii.analyze_text(data['text']['text'])
    else:
        message_input, replacements = data['text']['text'], []
    image_input = data['image']

    def ostream(): 
        if image_input != "":
            mysession['chathistory'].append(
                {"role": "user", "content": [{ "type": "text","text": message_input},{ "type": "image_url","image_url":{"url": image_input}}]}
            )
        else:
            mysession['chathistory'].append(
                {"role": "user", "content": [{ "type": "text","text": message_input}]}
            )
        #keep only the first system message and last 5 messages in chat history
        if len(mysession['chathistory']) > 11:
            sys = mysession['chathistory'][0]
            mysession['chathistory'] = [sys] + mysession['chathistory'][-10:]

        response = oaistreaming.get_streaming_response(chat_history= mysession['chathistory'],agent=agent)
        return response
    return app.response_class(response=stream_processor(ostream(),message_input, replacements),mimetype='text/event-stream')

@app.route('/callpromptflow', methods=['POST'])
def call_promptflow():
	data = request.get_json()
	message_input = data['text']
	mysession['requestbody']['question'] = message_input
	print(mysession['requestbody'])
	response = azureopenai.get_promptflow_response(mysession['requestbody'])

	mysession['requestbody']['chat_history'].append(
                {
                    "inputs": {"question": message_input},
                    "outputs": {"answer": response['answer']}
                }
    )
	
	return jsonify(response)

@app.route('/custom', methods=['GET'])
def custom_agent():
    x = json.dumps(agents.default_agent,ensure_ascii=False).encode('utf8').decode()
    return render_template('custom.html', default_config=x)

@app.route('/set_agent', methods=['POST'])
def set_agent():
    agent_config = request.form['agent_config']
    agent_config = json.loads(agent_config)
    mysession['agent'] = agent_config
    return redirect(url_for('chat', copilotname='custom'))

@app.route('/reductpii', methods=['POST'])
def reduct_pii():
    replace = True if request.args.get('replace') else False
    data = request.get_json()
    message_input = data['text']
    reducted = pii.analyze_single_text(message_input)
    result = {
        "result": reducted
        }
    return jsonify(result)


@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'),'favicon.ico', mimetype='image/vnd.microsoft.icon')

@app.route('/socket')
def socket():
    return render_template('socket.html')

@socketio.on("connect")
def connected():
    print("client has connected")
    emit("connect",f"user {request.sid} connected",broadcast=True)

@socketio.on('myevent')
def handle_message(data):
    print("data from the front end: ",str(data))
    emit("server",{'user': request.sid ,'data':data},broadcast=True)
    sleep(1)
    emit("server",{'user': request.sid ,'data':"clone"},broadcast=True)

@socketio.on("disconnect")
def disconnected():
    print("user disconnected")
    emit("disconnect",f"user {request.sid} disconnected",broadcast=True)

