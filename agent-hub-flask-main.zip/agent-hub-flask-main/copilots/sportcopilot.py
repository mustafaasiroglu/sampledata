sportcopilot =  {
               "id": "sportcopilot",
               "name": "Sport Copilot",
               "description": "Ask questions about sports, teams, and more!",
               "icon": "⚽",
               "active": False,
               "initialmessage": "Merhaba, hangi spor dalı hakkında bilgi almak istersin?",
               "sampleprompts":[
                  {"prompt": "Fenerbahçe'nin son maç sonucu nedir?"},
                  {"prompt": "Galatasaray'ın yeni transferi kim?"},
                  {"prompt": "Basketbolda bu hafta hangi maçlar var?"}
                  ],
               "system_prompt": "",
               "tools":[
                  {
                     "type": "function",
                     "function": {
                        "name": "search_user_manual",
                        "description": "Search the user manual for your car.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "query": {
                                 "type": "string",
                                 "description": "The search query to find in the user manual.",
                              },
                           },
                           "required": ["query"],
                        },
                     }
                  },
                  {
                     "type": "function",
                     "function": {
                        "name": "get_current_time",
                        "description": "Get the current time.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "location": {
                                 "type": "string",
                                 "description": "The location to get the current time for.",
                              }
                           },
                           "required": ["location"],
                        },
                     }
                  }
               ]
         }