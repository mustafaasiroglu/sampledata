financecopilot = {
               "id": "financecopilot",
               "name": "Finance Copilot",
               "description": "Ask questions about finance, investments, and more!",
               "icon": "💰",
               "active": False,
               "initialmessage": "Merhaba, bugün ne tür bir yatırım yapmak istersin?",
               "sampleprompts":[
                  {"prompt": "Borsada hangi hisseye yatırım yapmalıyım?"},
                  {"prompt": "Altın yatırımı hakkında bilgi verir misiniz?"},
                  {"prompt": "Kripto para yatırımı yapmak istiyorum."}
                  ],
               "system_prompt": "",
               "tools":[
                  {
                     "type": "function",
                     "function": {
                        "name": "search_user_manual",
                        "description": "Search the user manual for your car.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "query": {
                                 "type": "string",
                                 "description": "The search query to find in the user manual.",
                              },
                           },
                           "required": ["query"],
                        },
                     }
                  },
                  {
                     "type": "function",
                     "function": {
                        "name": "get_current_time",
                        "description": "Get the current time.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "location": {
                                 "type": "string",
                                 "description": "The location to get the current time for.",
                              }
                           },
                           "required": ["location"],
                        },
                     }
                  }
               ]
         }