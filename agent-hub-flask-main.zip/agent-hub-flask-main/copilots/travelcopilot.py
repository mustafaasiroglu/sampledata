travelcopilot =  {
               "id": "travelcopilot",
               "name": "Travel Copilot",
               "description": "Ask questions about travel, destinations, and more!",
               "icon": "🏦",
               "active": False,
               "initialmessage": "Merhaba, nereye seyahat etmek istersin?",
               "sampleprompts":[
                  {"prompt": "Yaz tatili için öneri var mı?"},
                  {"prompt": "Yurt dışına çıkmak için gereken belgeler nelerdir?"},
                  {"prompt": "En iyi plaj tatili destinasyonu hangisidir?"}
                  ],
               "system_prompt": "",
               "tools":[
                  {
                     "type": "function",
                     "function": {
                        "name": "search_user_manual",
                        "description": "Search the user manual for your car.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "query": {
                                 "type": "string",
                                 "description": "The search query to find in the user manual.",
                              },
                           },
                           "required": ["query"],
                        },
                     }
                  },
                  {
                     "type": "function",
                     "function": {
                        "name": "get_current_time",
                        "description": "Get the current time.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "location": {
                                 "type": "string",
                                 "description": "The location to get the current time for.",
                              }
                           },
                           "required": ["location"],
                        },
                     }
                  }
               ]
         }