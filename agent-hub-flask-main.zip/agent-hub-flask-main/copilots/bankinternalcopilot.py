bankinternalcopilot = {
               "id": "bankinternalcopilot",
               "name": "ABC Bank Agent Asistant",
               "description": "Ask questions about products, services, and more!",
               "icon": "💬",
               "active": True,
               "initialmessage": "Merhaba, size nasıl yardımcı olabilirim?",
               "sampleprompts":[
                  {"prompt": "Altın hesabı nasıl açılır?"},
                  {"prompt": "Yabancı uyruklu kişi müşteri olabiliyor mu?"},
                  {"prompt": "ABC Bank'nın diğer bankalardan farkı ne?"}
                  ],
               "system_prompt": """
               You are an AI assistant of ABC Bank digital banking and help you agents in customer call center by using knowledge base. Always give brief and friendly answers.
               
               Always use'search_knowledge_base_bankinternal' tool to search in knowledge base for information related with user query.
               
               """,
               "tools":[
                  {
                     "type": "function",
                     "function": {
                        "name": "get_current_datetime",
                        "description": "Get the current date time.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "location": {
                                 "type": "string",
                                 "description": "The location to get the current date time for.",
                              }
                           },
                           "required": ["location"],
                        },
                     }
                  },
                  {
               "type": "function",
               "function": {
                  "name": "search_knowledge_base_bankinternal",
                  "description": " Search the knowledge base for information for user query.",
                  "parameters": {
                     "type": "object",
                     "properties": {
                           "query": {
                              "type": "string",
                              "description": " The search query to find in the knowledge base.",
                           },
                     },
                     "required": ["query"],
                  },
               }
               }
               ]
         }