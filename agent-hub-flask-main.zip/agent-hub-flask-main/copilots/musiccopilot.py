musiccopilot = {
               "id": "musiccopilot",
               "name": "Music Copilot",
               "description": "Ask questions about music, artists, and more!",
               "icon": "🎵",
               "active": False,
               "initialmessage": "Merhaba, bugün hangi şarkıyı dinlemek istersin?",
               "sampleprompts":[
                  {"prompt": "En sevdiğin şarkıcı kim?"},
                  {"prompt": "Bugün hangi şarkıyı dinlemek istersin?"},
                  {"prompt": "Yeni çıkan bir albüm önerisi var mı?"}
                  ],
               "system_prompt": "",
               "tools":[
                  {
                     "type": "function",
                     "function": {
                        "name": "search_user_manual",
                        "description": "Search the user manual for your car.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "query": {
                                 "type": "string",
                                 "description": "The search query to find in the user manual.",
                              },
                           },
                           "required": ["query"],
                        },
                     }
                  },
                  {
                     "type": "function",
                     "function": {
                        "name": "get_current_time",
                        "description": "Get the current time.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "location": {
                                 "type": "string",
                                 "description": "The location to get the current time for.",
                              }
                           },
                           "required": ["location"],
                        },
                     }
                  }
               ]
         }