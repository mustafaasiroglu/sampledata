astrologycopilot = {
               "id": "astrologycopilot",
               "name": "Astrology Copilot",
               "description": "Ask questions about zodiac signs, horoscopes, and more!",
               "icon": "♈",
               "active": False,
               "initialmessage": "Merhaba, burcunla ilgili ne öğrenmek istersin?",
               "sampleprompts":[
                  {"prompt": "Koç burcunu bugün ne bekliyor?"},
                  {"prompt": "Yengeç burcu için günlük yorum nedir?"},
                  {"prompt": "İkizleri bu ay neler bekliyor?"}
                  ],
               "system_prompt": '''You are Togg’s Astrology Co-Pilot, an AI assistant specializing in astrology. Your role is to provide users with personalized astrological insights, natal chart interpretations, daily horoscopes, compatibility analysis, and guidance based on astrological principles. When users ask for astrological information, you call the “get_horoscope” function. You should create short, clear, and friendly answers. You should create answers of no more than 30 words. You communicate in a friendly, empathetic, and understanding tone. You respect a variety of beliefs and make sure your advice is empowering and unambiguous, emphasizing astrological leanings as well as free will. You also use cute emojis.

Ask the user about their zodiac sign, horoscope, and ascendant, and share your daily insights with the user.

Do not answer questions outside of these topics.''',
               "tools":[
                   {
            "type": "function",
            "function": {
                "name": "get_horoscope",
                "description": "Fetches the horoscope for a given zodiac sign.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "zodiac_Sign": {
                            "type": "string",
                            "description": "The zodiac sign for which to fetch the horoscope.",
                        },
                    },
                    "required": ["zodiac_Sign"],
                },
            }
        },
        {
               "type": "function",
               "function": {
                  "name": "get_current_time",
                  "description": "Get the current time.",
                  "parameters": {
                     "type": "object",
                     "properties": {
                        "location": {
                           "type": "string",
                           "description": "The location to get the current time for.",
                        }
                     },
                     "required": ["location"],
                  },
               }

         },
        {
            "type": "function",
            "function": {
                "name": "get_compatibility",
                "description": "Fetches the compatibility between two zodiac signs.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "zodiac_sign1": {
                            "type": "string",
                            "description": "The first zodiac sign for which to fetch the compatibility.",
                        },
                        "zodiac_sign2": {
                            "type": "string",
                            "description": "The second zodiac sign for which to fetch the compatibility.",
                        },
                    },
                    "required": ["zodiac_sign1", "zodiac_sign2"],
                },
            }
        },
        {
            "type": "function",
            "function": {
                "name": "get_birth_chart",
                "description": "Fetches the birth chart for a given user.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "The name of the user for which to fetch the birth chart.",
                        },
                        "year": {
                            "type": "integer",
                            "description": "The year of birth of the user.",
                        },
                        "month": {
                            "type": "integer",
                            "description": "The month of birth of the user.",
                        },
                        "day": {
                            "type": "integer",
                            "description": "The day of birth of the user.",
                        },
                        "hour": {
                            "type": "integer",
                            "description": "The hour of birth of the user.",
                        },
                        "minute": {
                            "type": "integer",
                            "description": "The minute of birth of the user.",
                        },
                        "longitude": {
                            "type": "number",
                            "description": "The longitude of the birth location of the user.",
                        },
                        "latitude": {
                            "type": "number",
                            "description": "The latitude of the birth location of the user.",
                        },
                        "city": {
                            "type": "string",
                            "description": "The city of the birth location of the user.",
                        },
                        "nation": {
                            "type": "string",
                            "description": "The nation of the birth location of the user.",
                        },
                        "timezone": {
                            "type": "string",
                            "description": "The timezone of the birth location of the user.",
                        },
                        "zodiac_type": {
                            "type": "string",
                            "description": "The type of zodiac to use for the birth chart.",
                        },
                    },
                    "required": ["name", "year", "month", "day", "hour", "minute", "longitude", "latitude", "city", "nation", "timezone"],
                },
            }
        }
         ]
    }