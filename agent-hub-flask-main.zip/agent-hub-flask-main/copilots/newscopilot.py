newscopilot ={
               "id": "newscopilot",
               "name": "News Copilot",
               "description": "Ask questions about current events, headlines, and more!",
               "icon": "📰",
               "active": False,
               "initialmessage": "Merhaba, bugün hangi haberleri öğrenmek istersin?",
               "sampleprompts":[
                  {"prompt": "Günlük haber özetini alabilir miyim?"},
                  {"prompt": "Son dakika haberleri nelerdir?"},
                  {"prompt": "Spor haberlerini öğrenmek istiyorum."}
                  ],
               "system_prompt": "",
               "tools":[
                  {
                     "type": "function",
                     "function": {
                        "name": "get_news",
                        "description": " Get the latest news headlines.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "query": {
                                 "type": "string",
                                 "description": "The search query to find in the news headlines.",
                              },
                           },
                           "required": ["query"],
                        },
                     }
                  }
               ]
         }