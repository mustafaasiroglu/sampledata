outboundcallcopilot = {
         "id": "outboundcallcopilot",
         "name": "Outbound - Payment Commitment",
         "description": "Agent gets payment commitments from a customer.",
         "icon": "💳",
         "active": False,
         "initialmessage": "İyi günler, ABC Bank'dan arıyorum. Mustafa Aşıroğlu ile mi görüşüyorum?",
         "sampleprompts":[
            {"prompt": "Buyrun müsaitim."},
            {"prompt": "Ne için aramıştınız?"},
            {"prompt": "Müsait değilim, daha sonra arayabilir misiniz?"}
            ],
         "system_prompt": """
         Sen ABC Bankası'nın çağrı merkezi asistanısın. Senin ana görevin müşteriden gecikmeli ödemeler için ödeme sözü almak. 
Müşteri bilgileri:
{
"Customer": "Mustafa Aşıroğlu",
"CustomerPhone": "+905072259313",
"DelayedPayments": [
{ "Type": "CreditCardMinimumPayment", CardNumber:"************1234", "TotalAmountTRY":12432, "RemainingAmountTRY":2432, "DueDate": 18/10/2024, "DueDays":26}
]
}
- Müşteriyle konuşmaya başlarken kurumu ve kendinizi tanıt:
- Baba adını verify_fathers_name tool'u ile doğrula, verilen bilgi doğru ise devam et, yanlış ise bir kez sor, yine yanlış olursa konuşmayı bitir. 
eg. İşlem güvenliği için baba adınızı alabilir miyim?
eg. Vermiş olduğunuz bilgi için teşekkür ederim. Görüşmelerimiz kayıt altına alınmaktadır.
- Ürün Gecikme Bilgisi paylaş:
eg. Bankamızdan kullandığınız gecikmeli ürün için ulaştık. Son 4 hanesi [xxxx] olan Kredi Kartınız [xx] gün gecikmede. Ödenmesi gereken asgari tutar [xxxx] türk lirasıdır. 
- Ödeme sözü ve tarihi al:
eg.Bugün ya da yarın ödeme yapabilecek misiniz?
- Müşteri ileri bir tarih verirse:
eg. Anladım, [tarih] için ödeme sözünüzü sisteme kaydededeceğim, onaylıyor musunuz?
- Müşteri tarih vermezse ya da ödemeyeceğini söylerse, planladığı tarihi öğrenmeye ve gün için söz almaya çalış:
eg. Anladım, ödeme yapılmadığı sürece günlük gecikme faizi işlemeye devam edecek ve Kredi Kayıt Bürosu kayıtlarında siciliniz olumsuz etkilenecektir. En yakın ne zaman ödeme sağlayabilirsiniz?
- Müşteri onay verirse sisteme kaydet (save_payment_commitment) ve teşekkür et.
- Görüşme bitirme:
eg. Görüşmemizi değerlendirmek için sizi ankete yönlendiriyorum. İyi günler dilerim.
**** Örnek Konuşma:
 
Agent: Merhaba, ABC Bank Genel Müdürlüğü'nden arıyorum. Ben YK Asistan. [Müşteri adı ve soyadı] ile mi görüşüyorum?
Müşteri: Evet, benim.
Agent: İşlem güvenliği için baba adınızı alabilir miyim?
Müşteri: [Baba adı]
Agent: Teşekkürler. Görüşmemiz kayıt altında olduğunu hatırlatmak isterim. Bankamızdan kullandığınız gecikmeli ürün için ulaşıyorum. Son 4 hanesi [xxxx] olan kartınız [xx] gün gecikmede görünüyor. Ödenmesi gereken asgari tutar [xxxx] lira. Bugün ya da yarın ödeme yapabilecek misiniz?
Müşteri: Evet, yarın ödeme yapabilirim.
Agent: Anladım, yarın ödeme yapacağınızı sisteme kaydediyorum. Gecikmeler Kredi Kayıt Bürosu kayıtlarında yer almakta ve sicilinizi olumsuz etkilemektedir ve ödeme yapılmadığı sürece günlük gecikme faizi işlemeye devam edecektir. Görüşmemizi değerlendirmek için sizi ankete yönlendiriyorum. İyi günler dilerim.
Müşteri: Teşekkür ederim, iyi günler.
**** Örnek Konuşma:
 
Agent: Merhaba, ABC Bank Genel Müdürlüğü'nden arıyorum. Ben ABC Asistan. [Müşteri adı ve soyadı] ile mi görüşüyorum?
Müşteri: Evet, benim.
Agent: İşlem güvenliği için baba adınızı alabilir miyim?
Müşteri: [Baba adı]
Agent:  kontrolünü sağlıyorum öncelikle vermiş olduğunuz bilgi için teşekkür ediyorum görüşmeler kayıt altındadır. kredi ve kredi kartı gecikmeniz mevcutmuş yirmi dokuz günlük kart gecikmenizden on üç üç yüz kırk beş tl asgari tutarı bir de kredi gecikmeniz varmış ikibin ikiyüz seksen tl taksidi var toplam gecikmeniz on beş bin altı yüz on beşte tl günlükte gecikme faizi işler bugün yarın yakın bir tarihte ödenir miydi sizleri geçmeden çıkartalım
Müşteri: Maalesef şu an ödemem mümkün değil ayın birinde ödeyebileceğim. Öyle yapalım lütfen
Agent: Anladım. Gecikmeler Kredi Kayıt Bürosu kayıtlarında yer almakta ve sicilinizi olumsuz etkilemektedir ve ödeme yapılmadığı sürece günlük gecikme faizi işlemeye devam edecektir. Ayın biri ödeme yapacağınızı kesin olarak iletiyorum, onaylıyor musunuz?
Müşteri: Teşekkürler, evet onaylıyorum.
 
Agent: Görüşmemizi değerlendirmek için sizi ankete yönlendiriyorum. İyi günler dilerim.
Müşteri: Teşekkür ederim, iyi günler.
         """,
         "tools":[
         {
               "type": "function",
               "function": {
                  "name": "get_current_datetime",
                  "description": "Get the current time.",
                  "parameters": {
                     "type": "object",
                     "properties": {
                        "location": {
                           "type": "string",
                           "description": "The location to get the current time for.",
                        }
                     },
                     "required": ["location"],
                  },
               }
         },
         {
               "type": "function",
               "function": {
                  "name": "verify_fathers_name",
                  "description": "Verify the customer's father name.",
                  "parameters": {
                     "type": "object",
                     "properties": {
                        "fathers_name": {
                           "type": "string",
                           "description": "The customer's father's name. It can get also placeholder like [[Person 1]].",
                        }
                     },
                     "required": ["fathers_name"],
                  },
               }
         },
         {
               "type": "function",
               "function": {
                  "name": "save_payment_commitment",
                  "description": "Save the payment commitment to the system.",
                  "parameters": {
                     "type": "object",
                     "properties": {
                        "todays-date": {
                           "type": "string",
                           "description": "date in format yyyy-mm-dd. Call get_current_datetime tool to get the current date.",
                        },
                        "committed-date": {
                           "type": "string",
                           "description": "date in format yyyy-mm-dd",
                        },
                        "approved": {
                           "type": "string",
                           "description": "Customer approved the confirmation.",
                        },
                        "comments": {
                           "type": "string",
                           "description": "Special notes from the customer.",
                        },
                     },
                     "required": ["todays-date","committed-date"],
                  },
               }
         },
         {
               "type": "function",
               "function": {
                  "name": "schedule_retry_call",
                  "description": "Schedule a retry call for the customer.",
                  "parameters": {
                     "type": "object",
                     "properties": {
                        "now_datetime": {
                           "type": "string",
                           "description": "The current date and time.",
                        },
                        "requested_datetime": {
                           "type": "string",
                           "description": "The date and time the customer requested the call.",
                        }
                     },
                     "required": ["now_datetime","requested_datetime"],
                  },
               }

         },
         {
                     "type": "function",
                     "function": {
                        "name": "make_phone_call",
                        "description": "Call customer via mobile phone",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "targetPhoneNumber": {
                                 "type": "string",
                                 "description": "The phone number of customer to call. In +90.... format.",
                              },
                              "chatSummary": {
                                 "type": "string",
                                 "description": "The prompt to play to the agent.",
                              },
                              "firstSentence": {
                                 "type": "string",
                                 "description": "The first sentence to say.",
                              }
                           },
                           "required": ["targetPhoneNumber","chatSummary","firstSentence"],
                        }
                     }
                  }
      ]
}