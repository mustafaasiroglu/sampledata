weathercopilot = {
               "id": "weathercopilot",
               "name": "Weather Copilot",
               "description": "Ask questions about the weather, forecasts, and more!",
               "icon": "☀",
               "active": False,
               "initialmessage": "Merhaba, hava durumu nasıl olacak?",
               "sampleprompts":[
                  {"prompt": "Yarın hava nasıl olacak?"},
                  {"prompt": "Hafta sonu hava durumu tahmini nedir?"},
                  {"prompt": "Yağmur yağacak mı?"}
                  ],
               "system_prompt": "",
               "tools":[
                  {
                     "type": "function",
                     "function": {
                        "name": "get_current_weather",
                        "description": "Get the current weather forecast.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "location": {
                                 "type": "string",
                                 "description": "The location to get the weather forecast for.",
                              }
                           },
                           "required": ["location"],
                        },
                     }
                  },
                  {
                     "type": "function",
                     "function": {
                        "name": "get_current_time",
                        "description": "Get the current time.",
                        "parameters": {
                           "type": "object",
                           "properties": {
                              "location": {
                                 "type": "string",
                                 "description": "The location to get the current time for.",
                              }
                           },
                           "required": ["location"],
                        },
                     }
                  }
               ]
         }