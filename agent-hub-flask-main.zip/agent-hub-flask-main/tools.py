import json, requests
from datetime import datetime, timedelta
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
import config
from datetime import datetime

def get_current_datetime(data):
    location = data["location"]
    current_datetime = datetime.now().strftime("%Y-%m-%d %I:%M %p")  
    return ({"location": location, "current_datetime": current_datetime})

def get_current_weather(data):
    try:
        location = data["location"]
        api_key = ""
        accuwather_location_endpoint = "http://dataservice.accuweather.com/locations/v1/cities/search"
        accuwather_location_url = accuwather_location_endpoint + "?apikey=" + api_key+ "&q=" + location
        locationkey = requests.get(accuwather_location_url).json()[0]["Key"]
        
        accuwather_api_endpoint = "http://dataservice.accuweather.com/currentconditions/v1/"
        accuwather_api_url = accuwather_api_endpoint + locationkey + "?apikey=" + api_key
        response = requests.get(accuwather_api_url)
        current_weather = response.json()
        
    except:
        current_weather = "Data not available. API Error"
    return ({"location": location, "current_weather": current_weather})


def search_knowledge_base(data):
    endpoint = config.carcopilot_search_endpoint
    index_name = config.carcopilot_search_index
    api_key = config.carcopilot_api_key

    search_client = SearchClient(endpoint=endpoint,
                                 index_name=index_name,
                                 credential=AzureKeyCredential(api_key))
    
    query = data.get("query", "")
    results = search_client.search(query,top=3, select=["title","chunk"])
    
    # Convert results to a list of dictionaries and limit the number of results
    results_list = [result for result in results][:3]
    
    return {"results": results_list}

def search_knowledge_base_bankinternal(data):
    endpoint = config.bankinternalcopilot_search_endpoint
    index_name = config.bankinternalcopilot_search_index
    api_key = config.bankinternalcopilot_api_key

    search_client = SearchClient(endpoint=endpoint,
                                 index_name=index_name,
                                 credential=AzureKeyCredential(api_key))
    
    query = data.get("query", "")
    results = search_client.search(query,top=3, select=["title","chunk"])
    
    # Convert results to a list of dictionaries and limit the number of results
    results_list = [result for result in results][:3]
    
    return {"results": results_list}


def search_lcw_products(data):
    endpoint = config.fashioncopilot_search_endpoint
    index_name = config.fashioncopilot_search_index
    api_key = config.fashioncopilot_api_key
    search_client = SearchClient(endpoint=endpoint,
                                 index_name=index_name,
                                 credential=AzureKeyCredential(api_key))
    
    query = data.get("query", "")
    results = search_client.search(query, top=3, select=["chunk", "mainImageUrl", "price", "title"])
    
    # Convert results to a list of dictionaries and limit the number of results
    results_list = [
        {
            "chunk": result["chunk"],
            "mainImageUrl": result["mainImageUrl"],
            "price": result["price"],
            "title": result["title"]
        } for result in results][:3]
    
    return {"results": results_list}

def search_products(data):
    endpoint = "https://ai-product-search.azurewebsites.net/api/search?q="
    query = data.get("query", "")

    response = requests.get(endpoint + query)
    results = response.json()

    return {"results": results}

def get_shows_and_movies(data):
    country_code = "TR"
    query = data["query"]
    current_time = datetime.now()
    shows_data = []
    movies_data = []
    tvshowsapi_movies_data = []
    
    if "tv şovları" in query.lower():
        # Fetch TV shows
        target_dates = [] 

        if "bugün" in query.lower():
            target_dates = [current_time.date()]
        elif "yarın" in query.lower():
            target_dates = [(current_time + timedelta(days=1)).date()]
        elif "bu hafta" in query.lower():
            target_dates = [(current_time + timedelta(days=i)).date() for i in range(7)]

        shows_url = 'https://api.tvmaze.com/schedule'

        if target_dates:
            for target_date in target_dates:
                shows_response = requests.get(shows_url, params={'country': country_code, 'date': target_date})
                
                if shows_response.status_code == 200:
                    shows = shows_response.json()
                    
                    for show in shows:
                        show_info = {
                            'date': target_date,
                            'channel': show['show']['network']['name'] if show['show']['network'] else 'N/A',
                            'name': show['show']['name'],
                            'airtime': show['airtime'],
                            'duration': show['show']['runtime'],
                            'type': show['show']['type']
                        }
                        shows_data.append(show_info)
                else:
                    return {"error": f"TV Shows API error: {shows_response.status_code}"}
        else:
            shows_response = requests.get(shows_url, params={'country': country_code})
            
            if shows_response.status_code == 200:
                shows = shows_response.json()
                
                for show in shows:
                    show_info = {
                        'date': current_time.date(),  
                        'channel': show['show']['network']['name'] if show['show']['network'] else 'N/A',
                        'name': show['show']['name'],
                        'airtime': show['airtime'],
                        'duration': show['show']['runtime'],
                        'type': show['show']['type']
                    }
                    shows_data.append(show_info)
            else:
                return {"error": f"TV Shows API error: {shows_response.status_code}"}

    if "filmler" in query.lower():
        # Fetch movies
        movies_url = "https://imdb-top-100-movies.p.rapidapi.com/"
        headers = {
            "x-rapidapi-key": "",
            "x-rapidapi-host": "imdb-top-100-movies.p.rapidapi.com"
        }
        movies_response = requests.get(movies_url, headers=headers)
        
        if movies_response.status_code == 200:
            movies = movies_response.json()
            for movie in movies:
                movie_info = {
                    'title': movie.get('title', 'N/A'),
                    'genre': movie.get('genre', 'N/A'),
                    'duration': movie.get('duration', 'N/A'), 
                    'year': movie.get('year', 'N/A'),
                    'rating': movie.get('rating', 'N/A')
                }
                movies_data.append(movie_info)
        else:
            return {"error": f"Movies API error: {movies_response.status_code}"}

        tvshowsapi_movies_url = "https://tvshow.p.rapidapi.com/Movie/1155089/Media"
        tvshowsapi_headers = {
            "x-rapidapi-key": "",
            "x-rapidapi-host": "tvshow.p.rapidapi.com"
        }
        tvshowsapi_movies_response = requests.get(tvshowsapi_movies_url, headers=tvshowsapi_headers)
        
        if tvshowsapi_movies_response.status_code == 200:
            tvshowsapi_movies = tvshowsapi_movies_response.json()
            for movie in tvshowsapi_movies:
                movie_info = {
                    'title': movie.get('title', 'N/A'),
                    'genre': movie.get('genre', 'N/A'),
                    'duration': movie.get('duration', 'N/A'), 
                    'year': movie.get('year', 'N/A'),
                    'rating': movie.get('rating', 'N/A')
                }
                tvshowsapi_movies_data.append(movie_info)
        else:
            return {"error": f"TV Shows Api Movies API error: {tvshowsapi_movies_response.status_code}"}

    result = {
        "TV Shows": shows_data,
        "Top 100 Movies": movies_data,
        "TV ShowsAPI Movies": tvshowsapi_movies_data
    }
    
    return result


def get_horoscope(zodiac_sign):

    url = "https://horostory.p.rapidapi.com/horoscope"
    querystring = {"sign": zodiac_sign, "date": "today"}
    headers = {
        "x-rapidapi-key": "",
        "x-rapidapi-host": "horostory.p.rapidapi.com"
    }
    
    try:
        response = requests.get(url, headers=headers, params=querystring)
        response.raise_for_status()  # Raise an HTTPError for bad responses
    except requests.exceptions.RequestException as e:
        response = f"API Error: {e}"
    
    return response

def get_birth_chart(name, year, month, day, hour, minute, longitude, latitude, city, nation, timezone, zodiac_type="Tropic"):
    url = "https://astrologer.p.rapidapi.com/api/v4/birth-chart"
    
    payload = {
        "subject": {
            "name": name,
            "year": year,
            "month": month,
            "day": day,
            "hour": hour,
            "minute": minute,
            "longitude": longitude,
            "latitude": latitude,
            "city": city,
            "nation": nation,
            "timezone": timezone,
            "zodiac_type": zodiac_type
        }
    }
    
    headers = {
        "x-rapidapi-key": "",
        "x-rapidapi-host": "astrologer.p.rapidapi.com",
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    return response.json()

# result = get_birth_chart("Paul", 1994, 10, 11, 9, 11, 12.4963655, 41.9027835, "Roma", "IT", "Europe/Rome")
    
def get_compatibility(zodiac_sign1, zodiac_sign2):
    url = "https://horoscope-and-panchanga.p.rapidapi.com/zodiac/ZodiacMatching"
    
    querystring = {"sign1": zodiac_sign1, "sign2": zodiac_sign2}
    
    headers = {
        "x-rapidapi-key": "",
        "x-rapidapi-host": "horoscope-and-panchanga.p.rapidapi.com"
    }
    
    response = requests.get(url, headers=headers, params=querystring)
    return response

# result = get_compatibility("Aries", "Pisces")

def get_news(query):
    url = "https://newsapi.org/v2/top-headlines"
    querystring = {
        "q": query,
        "country": "tr",
        "apiKey": ""
    }
    
    try:
        response = requests.get(url, params=querystring)
        response.raise_for_status()  # Raise an HTTPError for bad responses
        news = response.json()
    except requests.exceptions.RequestException as e:
        news = f"API Error: {e}"
    
    return news

def search_for_locations(data):
    my_location = data["my_location"]
    search_query = data["search_query"]
    url = "https://atlas.microsoft.com/geocode"

    querystring = {
        "api-version": "2023-06-01",
        "subscription-key": config.azuremaps_key,
        "query": my_location,
        "subscription-key":config.azuremaps_key
    }
    response1 = requests.get(url, params=querystring)

    print(response1.json()["features"][0]["geometry"]["coordinates"])

    lon = 29.0
    lat = 41.0
    try: 
        lon = response1.json()["features"][0]["geometry"]["coordinates"][0]
        lat = response1.json()["features"][0]["geometry"]["coordinates"][1] 
    except:
        False

    url2 = "https://atlas.microsoft.com/search/fuzzy/json"
    querystring2 = {
        "api-version": "1.0",
        "query": search_query,
        "lat": lat,
        "lon": lon,
        "language": "tr-TR",
        "countrySet" : "TR",
        "subscription-key":config.azuremaps_key
    }
    response2 = requests.get(url2, params=querystring2)
    return response2.json()

def generate_navigation_url(data):
    lat = data["lat"]
    lon = data["lon"]
    url = "https://www.google.com/maps/dir//"+ str(lat) + "," + str(lon)
    return url

def search_user_manual(data):
    search_term = data["query"]
    search_results = "API error. User manual connection not available."
    return ({"search_results": search_results})

def verify_fathers_name(data):
    fathers_name = data["fathers_name"].lower()
    if fathers_name == "ahmet":
        response = "Correct"
    else:
        response = "Incorrect"
    return ({"fathers_name": fathers_name, "response": response})

def save_payment_commitment(data):
    todays_date = data["todays-date"]
    committed_date = data["committed-date"]
    return ({"committed_date": committed_date, "result": "Payment commitment saved."})

def schedule_retry_call (data):
    now_datetime = data["now_datetime"]
    requested_datetime = data["requested_datetime"]
    return ({"result": "Call preference is saved."})

def make_phone_call(data):
    targetPhoneNumber = data["targetPhoneNumber"]
    chatSummary = data["chatSummary"]
    agentPrompt = """# Instructions

Sen ABC Bank'ın çağrı merkezi asistanısın. Senin ana görevin müşteriden gecikmeli ödemeler için ödeme sözü almak.

Customer Information:
{
"Customer": "Damla Alkan",
"DelayedPayments": [
{ "Type": "CreditCardMinimumPayment", CardNumber:"************1234", "TotalAmountTRY":12432, "RemainingAmountTRY":2432, "DueDate": 18/10/2024, "DueDays":26}
]
}

Latest conversation in text chat channel:
""" + chatSummary + """

# Call instructions

- Müşteriyle konuşmaya başlarken kurumu ve kendinizi tanıt:

 
Agent: Görüşmemizi değerlendirmek için sizi ankete yönlendiriyorum. İyi günler dilerim.

Müşteri: Teşekkür ederim, iyi günler.


      """

    #send http post request to 
    url = "https://agentless-callc"

    payload = {
        'targetPhoneNumber': targetPhoneNumber,
        'agentPrompt': agentPrompt,
        'firstSentence': "Merhaba, sizi ABC Bank'dan arıyorum. Müsait miydiniz?",
        'language': "tr-TR"
    }

        
    headers = {
        "Content-Type": 'application/json'
    }
    
    response = requests.post(url, headers=headers, json=payload).text

    callurl = "https://agentless-c/" + response

    response = "Aramayı başlattım. 📞. Konuşmamızı takip etmek için [buraya tıklayın](" + callurl + ")"
    return ({"phone_number": targetPhoneNumber, "response": response})

