import requests
import json
import os
import glob
import re
import config

endpoint = config.piiendpoint
key = config.piikey

piiCategories = [
    "PERSON",
    "TRNationalIdentificationNumber",
    "Email",
    "Address",
    "Organization",
    "age",
    "CreditCardNumber"
    ]

def convertrawtexttojson():
    #read rawinputs folder and convert each txt to json
    for filename in os.listdir("rawinputs"):
        if filename.endswith(".txt"):
            with open(f"rawinputs/{filename}", 'r', encoding='utf-8') as file:
                data = file.read()
                json_data = {
                    "Conversation": {
                        "Merged_content": data
                    }
                }
                with open(f"inputs/{filename.split('.')[0]}.json", 'w', encoding='utf-8') as file:
                    file.write(json.dumps(json_data))


   

def preproccess_text(text):
    # Lowercase only UPPERCASE words in the text
    text = re.sub(r'\b([A-Z]|\İ)+\b', lambda x: x.group().title(), text)
    return text


def masknumbers(text):
    # replace regex with index of the match
    text = re.sub(r'(\d[\d\s\.\-]*\d)+', lambda x: "[[Number]]", text)

    replacements = ["bir", "iki", "üç","dört","beş","altı","yedi","sekiz","dokuz","on","yüz","bin","milyon","milyar","trilyon"]
    
    for replacement in replacements:
        #text = text.replace(" "+replacement+" ", " * ")
        text = re.sub(r'\b'+replacement+r'\b', lambda x: "[[Number]]", text)
    return text

def analyze_text(text):

    # Sentence Case only UPPERCASE words in the text
    text = preproccess_text(text)

    url = endpoint
    headers = {
        "Content-Type": "application/json",
        "Ocp-Apim-Subscription-Key": key
    }
    
    body = {
        "kind": "PiiEntityRecognition",
        "parameters": {
            "modelVersion": "latest",
            "piiCategories": piiCategories
        },
        "analysisInput": {
            "documents": [
                {
                    "id": "1",
                    "language": "tr",
                    "text": text
                }
            ]
        }
    }

    response = requests.post(url, headers=headers, data=json.dumps(body))
    
    if response.status_code == 200:
        response_json = response.json()
        cat_counts = {}
        txt = response_json["results"]["documents"][0]["redactedText"]
        txtparts = []
        replacements = []
        start = 0
        for pii in response_json["results"]["documents"][0]["entities"]:
            beforestring = txt[start:pii["offset"]]
            piistring = txt[pii["offset"]:pii["offset"]+pii["length"]]
            cat = pii["category"].replace("", "")
            subcat = ":"+pii["subcategory"] if "subcategory" in pii else ""
            allcat = cat+subcat
            cat_counts[allcat] = cat_counts.get(allcat, 0) + 1
            mask = "[["+cat+subcat+" "+str(cat_counts[allcat])+"]]"
            txtparts.append(masknumbers(beforestring) + mask)    
            replacements.append((pii["text"], mask))
            start = pii["offset"]+pii["length"]
        txtreplaced = "".join(txtparts)+masknumbers(txt[start:])
        return txtreplaced, replacements
        
    else:
        return (response.status_code, response.text)


def analyze_texts_in_folder():
    url = endpoint
    headers = {
        "Content-Type": "application/json",
        "Ocp-Apim-Subscription-Key": key
    }
    # Get all JSON files in the specified folder
    txt_files = glob.glob(os.path.join('inputs', "*.txt"))

    for txt_file in txt_files:

        with open(txt_file, 'r', encoding='utf-8') as file:
            text = file.read()
            preprocceced_text = preproccess_text(text)
            piiresult = anayze_text(preprocceced_text)
            redactedText = postprocess_text(piiresult)
            #write files to output folder
            with open(f"outputs/{txt_file.split('\\')[-1]}", 'w', encoding='utf-8') as file:
                file.write(redactedText)

# Call the function with the path to the inputs folder
# convertrawtexttojson()

#analyze_texts_in_folder()

# test_text = "Adım Ahmet,  TC kimlik numaram 1234 5678 1234 5678 kredi kartı numaram 1234 5678 1234 5678. Adresim: İstanbul, Ataşehir, Atatürk Mahallesi, Atatürk Caddesi, 1234. Sokak, 12/1"
# res, rep = analyze_text(test_text)
# print(res)
# print(rep)
