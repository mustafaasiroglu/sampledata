from copilots.carcopilot import carcopilot
from copilots.tvcopilot import tvcopilot
from copilots.techcopilot import techcopilot
from copilots.newscopilot import newscopilot
from copilots.chefcopilot import chefcopilot
from copilots.astrologycopilot import astrologycopilot
from copilots.musiccopilot import musiccopilot
from copilots.weathercopilot import weathercopilot
from copilots.sportcopilot import sportcopilot
from copilots.travelcopilot import travelcopilot
from copilots.fashioncopilot import fashioncopilot
from copilots.financecopilot import financecopilot
from copilots.outboundcallcopilot import outboundcallcopilot
from copilots.outboundcallcopilot2 import outboundcallcopilot2
from copilots.bankfaqcopilot import bankfaqcopilot
from copilots.bankinternalcopilot import bankinternalcopilot
from copilots.productsearchcopilot import productsearchcopilot

default_agent = {
         "id": "default",
         "name": "Generic Copilot",
         "description": "Ask questions about any thing!",
         "icon": "💬",
         "active": False,
         "initialmessage": "Merhaba, sana nasıl yardımcı olabilirim?",
         "sampleprompts":[
            {"prompt": "Ankara'da hava nasıl?"},
            {"prompt": "Dünyada kaç ülke var?"},
            {"prompt": "Nasılsın?"}
            ],
         "system_prompt": "You are an AI assistant. You can answer questions on any topic. ",
         "tools": [
            {
               "type": "function",
               "function": {
                  "name": "get_current_datetime",
                  "description": "Get the current time.",
                  "parameters": {
                     "type": "object",
                     "properties": {
                        "location": {
                           "type": "string",
                           "description": "The location to get the current time for.",
                        }
                     },
                     "required": ["location"],
                  },
               }
            },
            {
               "type": "function",
               "function": {
                  "name": "get_current_weather",
                  "description": "Get the current weather.",
                  "parameters": {
                     "type": "object",
                     "properties": {
                        "location": {
                           "type": "string",
                           "description": "The location to get the weather for.",
                        }
                     },
                     "required": ["location"],
                  },
               }
            }
         ]
}

agents = [default_agent, tvcopilot, carcopilot, techcopilot, newscopilot, chefcopilot, astrologycopilot, musiccopilot, weathercopilot, travelcopilot, productsearchcopilot, fashioncopilot, financecopilot]